# Задача-1:
# Напишите скрипт, создающий директории dir_1 - dir_9 в папке,
# из которой запущен данный скрипт.


import os
import sys


def mk_dir(dir_name):
    os.path.join(os.getcwd(), dir_name)


# И второй скрипт, удаляющий эти папки.

def rem_dir(dir_name):
    os.rmdir(dir_name)


# Задача-2:
# Напишите скрипт, отображающий папки текущей директории.


def show_dirs(path=os.getcwd()):
    if os.listdir(path) != []:
        print('\nТекущая директория содержит:')
        for i in os.listdir(path):
            # if os.path.isdir(i): # если нужно отображать ТОЛЬКО папки
            print(i)
    else:
        print('\nТекущая директория пуста.')


# Задача-3:
# Напишите скрипт, создающий копию файла, из которого запущен данный скрипт.

def copy_file(path=sys.argv[0]):
    file = open(path, 'r', encoding='utf-8')
    str = file.read()
    file.close()
    file = open('copy_' + os.path.basename(path), 'w', encoding='utf-8')
    file.write(str)
    file.close()


# вызовы функций и демонстрация работы программы

# for i in range(9):
#     mk_dir('dir_' + str(i + 1))
#     print('Папка %s создана' % ('dir_' + str(i + 1)))
#
# show_dirs()
#
# print()
#
# for i in range(9):
#     rem_dir('dir_' + str(i + 1))
#     print('Папка %s удалена' % ('dir_' + str(i + 1)))
#
# copy_file()
