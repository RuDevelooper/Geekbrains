
class CTest:

    x = CDesc()

    def __init__(self):

        ...
        self.x = CDesc()

    def fn
    def fn2
