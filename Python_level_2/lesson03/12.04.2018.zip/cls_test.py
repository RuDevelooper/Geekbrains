
class CCls:

    def fn(self, a, b):

        ...

a
b
m1()
m2()

Mock

CCls.fn(m)

