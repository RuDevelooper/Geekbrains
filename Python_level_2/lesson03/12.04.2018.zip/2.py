
class CClient:

    def __getattribute__(self, key):

        # key -> ip

        return sock

cl = CClient()

cl.ip_127_0_0_1.send(b"123")

# __call__

