
class LOG:

    FNAME = "log.txt"

# LOG.FNAME

